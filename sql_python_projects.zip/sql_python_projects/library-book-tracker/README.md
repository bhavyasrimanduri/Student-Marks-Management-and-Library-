# Library Book Tracker

## Technologies Used
- SQL
- MySQL
- Excel

## Features
- Store book details
- Store member details
- Track borrowed books
- Find overdue records

## How to Run

1. Execute library.sql in MySQL

2. Run queries from queries.sql

3. Export results to Excel if needed
