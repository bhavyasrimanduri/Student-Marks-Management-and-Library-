CREATE DATABASE IF NOT EXISTS library_tracker;
USE library_tracker;

CREATE TABLE books (
    book_id INT PRIMARY KEY AUTO_INCREMENT,
    title VARCHAR(100) NOT NULL,
    category VARCHAR(50)
);

CREATE TABLE members (
    member_id INT PRIMARY KEY AUTO_INCREMENT,
    name VARCHAR(50) NOT NULL
);

CREATE TABLE borrow_records (
    record_id INT PRIMARY KEY AUTO_INCREMENT,
    book_id INT,
    member_id INT,
    borrow_date DATE,
    return_date DATE,
    FOREIGN KEY (book_id) REFERENCES books(book_id),
    FOREIGN KEY (member_id) REFERENCES members(member_id)
);

INSERT INTO books (title, category)
VALUES
('Data Science 101', 'Technology'),
('Business Fundamentals', 'Commerce'),
('C++ Programming', 'Technology');

INSERT INTO members (name)
VALUES
('Ravi'),
('Sneha'),
('Akash');

INSERT INTO borrow_records (book_id, member_id, borrow_date, return_date)
VALUES
(1, 1, '2024-05-01', NULL),
(2, 2, '2024-04-10', '2024-04-20');
