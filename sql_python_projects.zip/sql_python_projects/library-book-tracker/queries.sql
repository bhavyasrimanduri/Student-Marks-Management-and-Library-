USE library_tracker;

SELECT b.title, m.name, br.borrow_date
FROM borrow_records br
JOIN books b ON br.book_id = b.book_id
JOIN members m ON br.member_id = m.member_id
WHERE br.return_date IS NULL;

SELECT b.title, m.name, br.borrow_date
FROM borrow_records br
JOIN books b ON br.book_id = b.book_id
JOIN members m ON br.member_id = m.member_id
WHERE br.return_date IS NULL
AND DATEDIFF(CURDATE(), br.borrow_date) > 14;

SELECT COUNT(*) AS total_books
FROM books;

SELECT COUNT(*) AS total_members
FROM members;
